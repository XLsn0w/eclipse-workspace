/**
 * 小程序配置文件
 */
// var host = "wx.hzgolong.com"
var host = "192.168.100.127"

var config = {

  // 下面的地址配合云端 Server 工作
  host,
  //IP
  serverUrl: `http://${host}`,

  // 用code换取openId
  openIdUrl: `http://${host}/wechat/IsSign?mode=1`,

};

module.exports = config
