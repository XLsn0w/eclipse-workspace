var util = require("../../utils/util.js");
var app = getApp();
const openIdUrl = require('../../config').openIdUrl;
const serverUrl = require('../../config').serverUrl;
/*
 * 本页面为实名认证
 * inputUserName: 输入的姓名
 * inputCardID:   输入的身份证
*/
Page({

  data:{
    loginBtnTxt:"认证",
    loginBtnBgBgColor:"#034d91",
    btnLoading:false,
    disabled:false,
    inputUserName: '',
    inputCardID: '',
  },

  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    
  },

  onReady:function(){
    // 页面渲染完成
    
  },

  onShow:function(){
    // 页面显示
    this.autochecksign();
  },

  onHide:function(){
    // 页面隐藏
    
  },
  onUnload:function(){
    // 页面关闭
    
  },
  autochecksign: function () {
    var that = this;
    console.log('app.globalData', app.globalData);
    var city = wx.getStorageSync('city');
        wx.request({
          url: openIdUrl,
          data: {
            openid: app.globalData.openid,
            nickname: app.globalData.userInfo.nickName,
            city:city
          },
          success: function (res) {
            console.log('checkname拉取openid成功', res)
            if (res.data.RNameChecked) {
              if (res.data.isSign) {
                wx.redirectTo({
                  url: '../qrcode/index'
                })
              } else {
                // 从商户小程序跳转到微信签约小程序
                wx.navigateToMiniProgram({
                  appId: 'wxbd687630cd02ce1d', path: 'pages/index/index',
                  extraData: res.data.exdata
                  , success(res) {
                    // 成功跳转到签约小程序

                  }, fail(res) {
                    // 未成功跳转到签约小程序

                  }
                })
              }
             
            }
            

          },
          fail: function (res) {

          }
        })

   
  },
  //获取用户输入的用户名
  getNameInput: function (e) {
    this.setData({
      inputUserName: e.detail.value
    })
  },

  //获取用户输入的身份证
  getCardIDInput: function (e) {
    this.setData({
      inputCardID: e.detail.value
    })
  },

  formSubmit:function(e){
    var param = e.detail.value;
    var that = this;
    var realname   = param.username.trim();
    var cardId = param.password.trim();
    var city = wx.getStorageSync('city');
    if (realname.length > 0 && cardId.length > 0) {
      wx.request({
        url: serverUrl+'wechat/CheckRealName',
        data: {
          openid: app.globalData.openid,
          realname: realname,
          cardid: cardId,
          nickname: app.globalData.userInfo.nickName,
          city: city
        },
        success: function (res) {
          console.log('CheckRealName-----', res);

          // --------- 订单生成成功，发起支付请求 ------------------
          wx.requestPayment({
            timeStamp: res.data.timeStamp,
            nonceStr: res.data.nonceStr,   //字符串随机数
            package: res.data.package,
            signType: res.data.signType,
            paySign: res.data.paySign,
            'success': function (res) {
              console.log(res.errMsg);    //requestPayment:ok==>调用支付成功
              wx.showToast({
                title: '认证成功',
                icon: 'success',
                duration: 1000
              });

            },
            'fail': function (res) {
              console.log(res.errMsg);
            },
            'complete': function (res) {
              console.log(res.errMsg);
            }
          })


        },

        fail: function (res) {

        }
      })
    } else {
      wx.showModal({
        title: '提示',
        showCancel: false,
        content: '请输入姓名和身份证'
      });
    }
    console.log('app.globalData', app.globalData);

  },

  mysubmit:function (param){
    var flag = this.checkUserName(param)&&this.checkPassword(param)
    // if(flag){
    //     this.setLoginData1();
    //     this.checkUserInfo(param);
    // } 

    wx.navigateTo({
      url: '../phone/index'
    })
  }

})