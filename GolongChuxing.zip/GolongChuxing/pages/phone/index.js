var util = require("../../utils/util.js");
var cfg = require('../../config');
const openIdUrl = cfg.openIdUrl;
const serverUrl = cfg.serverUrl;
var app = getApp();
Page({
  data:{
    registBtnTxt:"完成",
    registBtnBgBgColor:"#034d91",
    getSmsCodeBtnTxt:"获取验证码",
    getSmsCodeBtnColor:"#034d91",
    btnLoading:false,
    registDisabled:false,
    smsCodeDisabled:false,
    inputUserName: '',
    inputPassword: '',
    phoneNum: '',
    extraData:null
  },

  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    app.getUserOpenId(this.initfun);
  },
  onReady:function(){
    // 页面渲染完成
    
  },
  onShow: function (res) {
    // 页面显示
    this.autochecksign();
    console.log('serverUrl---' + serverUrl);
  },
  onHide:function(){
    // 页面隐藏
    
  },
  onUnload:function(){
    // 页面关闭
    
  },

  initfun:function(t,openid){
    app.getUserInfo(this.getexterData);
  },

  autochecksign: function () {
    var that = this;
    wx.login({
      success: function (data) {
        wx.request({
          url: openIdUrl,
          data: {
            code: data.code
          },
          success: function (res) {
            console.log('拉取openid成功', res)
            //已经绑定、不需要实名
            if (res.data.bindMobile && res.data.needCheck == false) {
              wx.redirectTo({
                url: '../../pages/qrcode/index'
              })
            }
          },
          fail: function (res) {

          }
        })
      },
      fail: function (err) {
      }
    });
  },
  
  getexterData: function (usinfo) {
    console.log('拉取userinfo成功', usinfo);
    this.setData({
      userinfo: usinfo,
    });
  },

  formSubmit:function(e){
    var param = e.detail.value;
    //this.mysubmit(param);
    var that = this;
    console.log('serverUrl', serverUrl);
    var city = wx.getStorageSync('city');
    wx.request({
      url: serverUrl+'wechat/BindMobile',
      data: {
        openid: app.globalData.openid,
        mobile: param.username,
        code: param.smsCode,
        nickname: that.data.userinfo.nickName,
        city:city
      },
      success: function (exdata) {
        console.log('拉取bindmobile success', exdata)
        if(exdata.data.result){
          //绑定成功后判定是否需要实名认证
          if (!exdata.data.needCheck){
            if (!exdata.data.isSign) {
              if (app.VersionCompare(app.globalData.version, '6.5.9')) {
                wx.showToast({
                  title: '请将您的微信升级到6.5.9以上',
                  icon: 'error',
                  duration: 5000
                })
              } else {
                // 从商户小程序跳转到微信签约小程序
                wx.navigateToMiniProgram({
                  appId: 'wxbd687630cd02ce1d', path: 'pages/index/index',
                  extraData: exdata.data.exdata
                  , success(res) {
                    // 成功跳转到签约小程序

                  }, fail(res) {
                    // 未成功跳转到签约小程序

                  }
                });
              }
            } else {
              wx.redirectTo({
                url: '../../pages/qrcode/index'
              })
            }
          }else{
            if (exdata.data.RNameChecked){
              wx.redirectTo({
                url: '../../pages/qrcode/index'
              })
            }else{
              wx.redirectTo({
                url: '../name/index'
              })
            }

          }
        
         
         

        }else{
          wx.showToast({
            title: '验证失败',
            icon: 'error',
            duration: 1000
          });

        }
      },
      fail: function (res) {
        console.log('拉取bindmobile失败', res)

      }
    })
  },

  getPhoneNum:function(e){
  var that = this;
   var value  = e.detail.value;
   console.log('value---'+value);
   that.setData({
    phoneNum: value     
   });
  },

  checkUserName:function(param){ 
    var phone = util.regexConfig().phone;
    var inputUserName = param.trim();
    console.log('bool-'+phone.test(inputUserName));
    console.log('phone-'+phone);
    console.log('inputUserName-' + inputUserName);
    if(phone.test(inputUserName)){
      return true;
    }else{
      wx.showModal({
        title: '提示',
        showCancel:false,
        content: '请输入正确的手机号码'
      });
      return false;
    } 
  },

  getSmsCode:function(){
    var that = this;
    var phoneNum = that.data.phoneNum;
    console.log('serverUrl---' + serverUrl);
    var that = this;
    var count = 60;
    if(this.checkUserName(phoneNum)){
      //
      var that = this;
      wx.request({
        url: serverUrl+'wechat/GetRandom',
        data: {
          openid: app.globalData.openid,
          mobile: phoneNum
        },
        success: function (exdata) {
          console.log('拉取random success', exdata)
          wx.showToast({
            title: '验证码发送成功',
            icon: 'error',
            duration: 1000
          })
        },
        fail: function (res) {
          console.log('拉取random失败', res)
         
        }
      })
      var si = setInterval(function(){
      if(count > 0){
        count--;
        that.setData({
          getSmsCodeBtnTxt:count+' s',
          getSmsCodeBtnColor:"#999",
          smsCodeDisabled: true
        });
      }else{
        that.setData({
          getSmsCodeBtnTxt:"获取验证码",
          getSmsCodeBtnColor:"#034d91",
          smsCodeDisabled: false
        });
          count = 60;
          clearInterval(si);
        }
      },1000);
    }
    
  },

  checkSmsCode:function(param){
    var smsCode = param.smsCode.trim();
    var tempSmsCode = '000000';//演示效果临时变量，正式开发需要通过wx.request获取
    if(smsCode!=tempSmsCode){
      wx.showModal({
        title: '提示',
        showCancel:false,
        content: '请输入正确的短信验证码'
      });
      return false;
    }else{
      return true;
    }
  }
 
})