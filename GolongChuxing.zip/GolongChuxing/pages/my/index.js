const app = getApp()

Page({

  data: {
    userInfo: {},
    animationAvatar: {}
  },

  onLoad() {
    this.getUserInfo();
    this.beginAnimation();
  },

  onShow: function () {
    this.beginAnimation();
  },

  beginAnimation: function () {
    var animation = wx.createAnimation({
      timingFunction: 'ease'
    })
    this.animation = animation;
    this.animation_1();
    var that = this;
    setTimeout(function () { that.animation_2(); }, 2000);

    this.setData({
      animationAvatar: animation.export()
    })

  },

  getUserInfo: function (cb) {
    var that = this
    wx.login({
      success: function () {
        wx.getUserInfo({
          success: function (res) {
            that.setData({
              userInfo: res.userInfo
            });
          }
        })
      }
    })
  },

  // 旋转、放大、平移
  animation_1: function () {
    this.animation.rotate(360).translate(0, 0).scale(1.3, 1.3).step({ duration: 2000 })
    this.setData({
      animationAvatar: this.animation.export()
    })
  },

  // 旋转、缩小、平移
  animation_2: function () {
    this.animation.rotate(360).translate(0, 0).scale(1, 1).step({ duration: 2000 })
    this.setData({
      animationAvatar: this.animation.export()
    })
  },

  ///record
  record: function () {
    wx.navigateTo({
      url: '../drivingRecord/drivingRecord'
    })
  },

  line: function () {
    wx.navigateTo({
      url: '../openingLine/openingLine'
    })
  },

  ///进入卡包
  card: function () {
    var that = this;
    var city = wx.getStorageSync('city');
    console.log('openid---', app.globalData.openid)
    console.log('city---', city)
    wx.request({
      url: 'https://wx.hzgolong.com/wechat/addusercard',
      data: {
        openid: app.globalData.openid,
        city: city
      },
      success: function (res) {
        console.log('addCard---------', res)
        if (res.data.hasCard == false) {
          ///如果没有添加过卡劵,则执行addCard
          wx.addCard({
            cardList: res.data.cardList,
            success: function (res) {
              //console.log('res.cardList-----', res.cardList) // 卡券添加结果
            },
            fail: function (res) {
              //console.log(res.cardList) // fail 卡券添加结果
            }
          })
        } else {
          ///否则执行openCard, 打开卡券
          wx.openCard({
            cardList: res.data.cardList,
            success: function (res) {

            },
            fail: function () {

            }
          })
        }

      },
      fail: function (res) {
        console.log('请求失败');
      }
    })

  },

  guide: function () {
    wx.navigateTo({
      url: '../guide/index'
    })
  },

  aboutUs: function () {
    wx.showModal({
      title: '关于我们',
      content: '朗朗出行-乘车码©杭州国朗科技有限公司',
      showCancel: false
    })
  }

})
