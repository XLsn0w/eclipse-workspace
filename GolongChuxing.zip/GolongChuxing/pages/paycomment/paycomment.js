var app = getApp()

Page({

  data: {
    price: '2.00',
    loginBtnBgBgColor: "#41a40c",
  },

  onShow: function () {
    var pageslist = getCurrentPages();
    console.log('pageslist---' + pageslist);
  },

  done: function (event) {

    console.log('xxxxxx')
  }

})