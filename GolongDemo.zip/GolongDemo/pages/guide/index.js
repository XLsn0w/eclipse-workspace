const app = getApp()

Page({

  data: {
    userInfo: {},
  },

  onLoad() {
    this.getUserInfo();
  },

  getUserInfo: function (cb) {
    var that = this
    wx.login({
      success: function () {
        wx.getUserInfo({
          success: function (res) {
            that.setData({
              userInfo: res.userInfo
            });
          }
        })
      }
    })
  },

  ///record
  record: function () {
    wx.navigateTo({
      url: '../drivingRecord/drivingRecord'
    })
  },

  line: function () {
    wx.navigateTo({
      url: '../openingLine/openingLine'
    })
  },

  ///进入卡包
  card: function () {
    var that = this;
    var city = wx.getStorageSync('city');
    console.log('openid---', app.globalData.openid)
    console.log('city---', city)
    wx.request({
      url: 'https://wx.hzgolong.com/wechat/addusercard',
      data: {
        openid: app.globalData.openid,
        city: city
      },
      success: function (res) {
        console.log('addCard---------', res)
        if (res.data.hasCard == false) {
          ///如果没有添加过卡劵,则执行addCard
          wx.addCard({
            cardList: res.data.cardList,
            success: function (res) {
              //console.log('res.cardList-----', res.cardList) // 卡券添加结果
            },
            fail: function (res) {
              //console.log(res.cardList) // fail 卡券添加结果
            }
          })
        } else {
          ///否则执行openCard, 打开卡券
          wx.openCard({
            cardList: res.data.cardList,
            success: function (res) {

            },
            fail: function () {

            }
          })
        }

      },
      fail: function (res) {
        console.log('请求失败');
      }
    })

  },

  guide: function () {

  },

  aboutUs: function () {
    wx.showModal({
      title: '关于我们',
      content: '朗朗出行-乘车码©杭州国朗科技有限公司',
      showCancel: false
    })
  }

})
