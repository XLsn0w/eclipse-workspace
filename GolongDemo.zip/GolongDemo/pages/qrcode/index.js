// pages/main/index.js
const openIdUrl = require('../../config').openIdUrl;
const serverUrl = require('../../config').serverUrl;
var QR = require("../../utils/qrcode.js");
var app = getApp();
var minute = 1;
var networkType = '';
var ist = null;

Page({
  /*******this.data*******/
  data: {
    issign: true,
    bindMobile: false,
    maskHidden: true,
    imagePath: '',
    userInfo: {},
    cityName: '杭州市',
    isGetLocal: false,
    isAddCard: true,
    latitude: '',
    longitude: '',
    code: '',
    cardId: '',
    extraData: {},
    protocolColor: '#00f',
    placeholder: '',
    checkProtocol: 'B',
    isgetuser: false,
    flashflag: 0,
    array: ['杭州市'],
    keyarray: ['杭州市'],
    showcard: true,
    index: 0,
    currentBrightness: 0,
    indicatorDots: true,
    autoplay: false,
    interval: 2000,
    duration: 500,
    isPopping: true,
    animationPlus: {},
    animationBus: {},
    animationLine: {},
    animationCard: {},
    animationShare: {},
    animationAvatar: {},
    showDialog: false,
    showCenterDialog: false,
  },

  /**********************************************************************************
  **********************************生命周期******************************************
  **********************************************************************************/

  onLoad: function (options) {
    this.setDefaultCity();
    wx.showShareMenu();
    this.beginAnimation();
  },

  ///监听小程序显示
  onShow: function (options) {
    console.log('qronShow options',options);
    var that = this;
    that.clearqrcode('');
    that.showLoading();
    wx.getScreenBrightness({
      success: function (res) {
        console.log('当前屏幕亮度指数-------', res.value)
        that.setData({
          currentBrightness: res.value
        });
      }
    });

    minute = 1;
    clearInterval(ist);
    that.getUserData();
    that.getWXSystemInfo();
    // that.judgeCardFunc();
    var city = wx.getStorageSync('city');
    if (city.length > 0) {
      that.setData({
        cityName: city
      });
    } else {
      that.setData({
        cityName: '切换城市'
      });
    };
    if (that.data.issign) {
      /// 设置屏幕亮度
      wx.setScreenBrightness({
        value: 0.8
      })
    }
    
    ///头像动画
    this.beginAnimation();
  },

  onReady: function () {
    var navTitle = this.data.keyarray[this.data.index];
    var city = wx.getStorageSync('city');
    console.log('city-------', this.data.cityName);

    wx.setNavigationBarTitle({
      title: '国朗演示'
    })

  },

  onHide: function () {
    //页面隐藏
    clearInterval(ist);
    console.log('qrcode-onHide')
    /// 设置屏幕亮度
    wx.setScreenBrightness({
      value: this.data.currentBrightness
    })
  },

  onUnload: function () {
    //页面关闭
    //clearInterval(this.screateQrcode());
    clearInterval(ist);
    console.log('qrcode-onUnload')
  },

  onPullDownRefresh: function () {
    console.log('刷新');
  },

  /**********************************************************************************
  **********************************自定义函数*****************************************
  **********************************************************************************/

  onClickButton: function (e) {
    let that = this;
    that.setData({
      showCenterDialog: !this.data.showCenterDialog
    });
  },

  onClickdiaCenterView: function () {
    console.log('----------');
    this.setData({
      showCenterDialog: !this.data.showCenterDialog
    });
  },

  ///获取手机号
  getPhoneNumber: function (e) {
    console.log('errMsg-------', e.detail.errMsg)
    if (e.detail.errMsg == 'getPhoneNumber:ok') {
      console.log('确定');
      var iv = e.detail.iv;
      var encryptedData = e.detail.encryptedData;
      console.log('iv->', iv);
      console.log('encryptedData->', encryptedData);
    ///解密encryptedData
      var that = this;
      wx.login({
        success: function (data) {
          var city = wx.getStorageSync('city');
          wx.request({
            url: 'https://wx.hzgolong.com/wechat/EncryptedBindPhone',
            data: {
              data: encryptedData,
              iv: iv,
              code: data.code,
              city: city,
              nickname: that.data.userInfo.nickName
            },
            success: function (res) {
              console.log('res-------', res)
              if (res.data.isSign == false) {
                // 从商户小程序跳转到微信签约小程序
                wx.navigateToMiniProgram({
                  appId: 'wxbd687630cd02ce1d', path: 'pages/index/index',
                  extraData: res.data.exdata
                  , success(res) {

                  }, fail(res) {
                    // 未成功跳转到签约小程序
                  }
                });
              } else {
                that.setData({
                  issign: true
                });
              }
            },
            fail: function (res) {

            }
          })
        },
        fail: function (err) {

        }
      })


    } else {
      console.log('取消');
      this.btnRegisterTap();
    }
  },

  ///开始动画
  beginAnimation: function () {
    var animation = wx.createAnimation({
      timingFunction: 'ease'
    })
    this.animation = animation;
    this.animation_1();
    var that = this;
    setTimeout(function () { that.animation_2(); }, 2000);

    this.setData({
      animationData: animation.export()
    })

  },

  // 旋转、放大、平移
  animation_1: function () {
    this.animation.rotate(360).translate(0, 0).scale(1.8, 1.8).step({ duration: 2000 })
    this.setData({
      animationAvatar: this.animation.export()
    })
  },
  // 旋转、缩小、平移
  animation_2: function () {
    this.animation.rotate(360).translate(0, 0).scale(1, 1).step({ duration: 2000 })
    this.setData({
      animationAvatar: this.animation.export()
    })
  },

  ///我的个人中心
  my: function () {
    wx.navigateTo({
      url: '../my/index'
    })
  },
  
  ///弹出菜单
  plus: function () {
    console.log('isPopping-----------', this.data.isPopping);
    if (this.data.isPopping) {
      ///打开菜单
      popp.call(this);
      this.setData({
        isPopping: false
      })
    } else {
      ///关闭菜单
      takeback.call(this);
      this.setData({
        isPopping: true
      })
    }
  },

  ///进入乘车记录
  bus: function () {
    console.log('进入乘车记录');
    wx.navigateTo({
      url: '../drivingRecord/drivingRecord'
    })
  },

  ///进入开通线路
  line: function () {
    console.log('进入开通线路');
    wx.navigateTo({
      url: '../openingLine/openingLine'
    })
  },
  
  onItemClick: function (event) {
    var id = event.target.dataset.id;
    console.log('click', id);
    if (id == 1) {
      wx.navigateTo({
        url: '../service/service'
      })
    } else if (id == 2) {
      wx.navigateTo({
        url: '../service/service'
      })
    } else {
      wx.navigateTo({
        url: '../service/service'
      })
    }
  },

  //分享
  onShareAppMessage: function (options) {
    var city = wx.getStorageSync('city');


    return {
      title: '分享' + city + '城市公交乘车码',
      path: '/pages/qrcode/index?openid=' + app.globalData.openid + '&city=' + city,
      success: function (options) {
        // 转发成功
        console.log('options---', options);
        console.log('shareTickets---', options.shareTickets);
      },
      fail: function (options) {
        // 转发失败
      }
    };


  },

  ///分享
  shared: function () {
    wx.updateShareMenu({
      withShareTicket: true,
      success() {
      }
    })
    wx.showShareMenu({
      withShareTicket: true
    });
    this.onShareAppMessage();
  },

  clearqrcode: function (val) {
    var that = this;
    const ctx = wx.createCanvasContext('mycanvas')
    ctx.setFontSize(20)
    ctx.fillText(val, 100, 100)
    ctx.draw()
  },

  bindPickerChange: function (e) {
    var that = this;
    var tempcityName = that.data.cityName;
    var city = that.data.array[e.detail.value];
    if (tempcityName!=city){
      that.clearqrcode('');
      that.showLoading();
      console.log('city---', city)
      wx.setStorage({
        key: 'city',
        data: city,
        success: function (res) {
          console.log('异步保存成功')
        }
      })
      wx.setStorageSync('city', city);
      console.log('同步保存成功')
      that.setData({
        cityName: city,
        index: e.detail.value
      });
      that.ingetUserData()

      var navTitle = that.data.keyarray[e.detail.value];
      console.log('navTitle-------', navTitle);
      wx.setNavigationBarTitle({
        title: navTitle
      })
    }
   
  },

  ///进入卡包
  card: function () {
    var that = this;
    var city = wx.getStorageSync('city');
    console.log('openid---', app.globalData.openid)
    console.log('city---', city)
    wx.request({
      url: 'https://wx.hzgolong.com/wechat/addusercard',
      data: {
        openid: app.globalData.openid,
        city: city
      },
      success: function (res) {
        console.log('addCard---------', res)
        if (res.data.hasCard == false) {
          ///如果没有添加过卡劵,则执行addCard
          wx.addCard({
            cardList: res.data.cardList,
            success: function (res) {
              //console.log('res.cardList-----', res.cardList) // 卡券添加结果
            },
            fail: function (res) {
              //console.log(res.cardList) // fail 卡券添加结果
            }
          })
        } else {
          ///否则执行openCard, 打开卡券
          wx.openCard({
            cardList: res.data.cardList,
            success: function (res) {

            },
            fail: function () {

            }
          })
        }

      },
      fail: function (res) {
        console.log('请求失败');
      }
    })

  },

  ///设置默认城市为乐清市
  setDefaultCity: function () {
    var city = '杭州市';
    console.log('city---', city)
    wx.setStorage({
      key: 'city',
      data: city,
      success: function (res) {
        console.log('异步保存成功')
      }
    })
    wx.setStorageSync('city', city);
    console.log('同步保存成功')
    this.setData({
      cityName: city
    });

  },

  /// 得到当前屏幕亮度
  getCurrentScreenBrightness: function () {
    wx.getScreenBrightness({
      success: function (res) {
        console.log('当前屏幕亮度指数-------', res.value)
        this.setData({
          currentBrightness: res.value
        });
      }
    });
  },

  getWXSystemInfo: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        console.log('systeminfo', res);
        var version = res.version;//parseFloat(res.version.replace('.', '').replace('.',''));
        that.setData({
          version: res.version,
          model: res.model
        });
        app.globalData.version = version;

        if (app.VersionCompare(app.globalData.version, '6.5.9')) {
          wx.showToast({
            title: '请将您的微信升级到6.5.9以上',
            icon: 'error',
            duration: 2000
          });
        }
        console.log('version:', version);
      }
    })
  },

  // 获取当前位置；
  getLocation() {
    console.log('getLocation');
    var that = this;
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        //当前经纬度
        console.log('纬度经度' + true, res);
        that.setData({
          latitude: res.latitude,
          longitude: res.longitude,
          isGetLocal: true
        });
        that.loadCity(res.longitude, res.latitude);
      },
      fail: function () {
        console.log('location fail');
        //app.getUserOpenId(that.autochecksign);//modify by luo 2017-8-24 改为只在注册里取坐标
      }
    })
  },

  loadCity: function (longitude, latitude) {
    var page = this;
    var city = wx.getStorageSync('city');
    wx.request({
      url: 'https://api.map.baidu.com/geocoder/v2/?ak=4XQVBa1VBC9zBVOrY9ZPrwjn9oip2qMf&location=' + latitude + ',' + longitude + '&output=json',
      data: {},
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        // success  
        console.log('baiducity', res);
        var city = res.data.result.addressComponent.city;
        var tempcity = page.data.cityName;

        if (city != tempcity) {
          for (var i = 0; i < page.data.array.length; i++) {
            if (city == page.data.array[i]) {
              page.setData({ cityName: city, index: i });
              wx.setStorageSync('city', city);
              /*
              wx.setNavigationBarTitle({
                title: city + '城市公交乘车码'
              })
              */
              var navTitle = page.data.keyarray[i];
              wx.setNavigationBarTitle({
                title: navTitle
              })
            }
          }

          // page.getUserData();
          //app.getUserOpenId(page.autochecksign);//8-18改动by luo
        }
        //app.getUserOpenId(page.autochecksign);//8-18改动by luo 8-24注释
      },
      fail: function () {

        // fail  
      },
      complete: function () {
        // complete  
      }
    });
  },

  // 获取当前用户；
  getUserData() {
    var that = this;

    if (!app.globalData.isgetPromission) {
      console.log('isgetPromission');
      wx.login({
        success: function () {
          app.globalData.isgetPromission = true;
          that.ingetUserData();
        }
      });
    } else {
      that.ingetUserData()
    }
  },

  showLoading: function () {
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 5000
    });
  },

  ingetUserData: function () {
    console.log('ingetuserdata');
    var that = this;
    wx.getUserInfo({
      success: function (res) {
        var userInfo = res.userInfo;
        console.log('qrcode-userInfo', userInfo);
        app.globalData.userInfo = res.userInfo;
        //更新数据
        if (userInfo != null) {
          app.globalData.isgetPromission = true;
          that.setData({
            userInfo: userInfo,
            isgetuser: true
          });

        } else {
          that.setData({
            issign: false
          })
        }
        //that.getLocation();
        app.getUserOpenId(that.autochecksign);//2017-8-24 modify by luo
      },
      fail: function (res) {
        console.log('getuserdata-fail', res);
        that.offlineCreateQrcode();
      }
    });
  },
  checkboxChange: function (e) {
    var that = this;
    that.setData({
      checkProtocol: e.detail.value
    })
    if (e.detail.value) {
      if (e.detail.value == 'B') {
        console.log('checkbox发生chang事件', e.detail.value);
        that.setData({
          protocolColor: '#00f'
        })
      } else {
        that.setData({
          protocolColor: '#888'
        });
      }

    } else {
      console.log('null');
      that.setData({
        protocolColor: '#888'
      });
    }
  },

  initscreateQrcode: function (t, openid) {
    this.setData({
      openid: openid,
      issign: t
    });
    //app.getUserInfo(this.getexterData);
  }
  ,
  getexterData: function (usinfo) {
    console.log('拉取userinfo成功', usinfo);
    this.setData({
      userinfo: usinfo,
    });
    var that = this;
    wx.request({
      url: 'https://wx.hzgolong.com/wechat/sign',
      data: {
        openid: that.data.openid
      },
      success: function (exdata) {
        console.log('拉取sign success', exdata)
        that.setData({
          extraData: exdata.data,
        });
        that.screateQrcode();
        var st = setTimeout(function () {
          var size = that.setCanvasSize();
          //绘制二维码
          //that.createQrCode(url,"mycanvas",size.w,size.h);
          that.setData({
            maskHidden: true
          });
          clearTimeout(st);
        }, 1000)
      },
      fail: function (res) {
        console.log('拉取sign失败，将无法正常使用开放接口等服务', res)
        callback(res)
      }
    })
  }
  ,
  screateQrcode: function () {
    var that = this;
    if (app.globalData.hasLogin === false) {
      console.log('needloging');
      wx.login({
        success: function (data) {
          _getUserInfo();
          app.globalData.hasLogin = true;
        }
      });
    } else {
      _getUserInfo()
    }

    function _getUserInfo() {
      console.log('app.globalData.qrindex', app.globalData.qrindex);
      var size = that.setCanvasSize();//动态设置画布大小
      wx.getNetworkType({
        success: function (res) {
          networkType = res.networkType; // 返回网络类型2g，3g，4g，wifi, none, unknown
          console.log('networkType', networkType);
          if (networkType != 'none') {
            var city = that.data.cityName;//wx.getStorageSync('city');
            console.log('madecode city', city);
            wx.request({
              url: 'https://wx.hzgolong.com/wechat/madecode',
              data: {
                openid: that.data.openid,
                city: '杭州市',
                time: new Date()
              },
              success: function (exdata) {
                if (exdata.data.mxqrcode.length > 0) {
                  app.globalData.qrcodes = exdata.data.items;
                  app.globalData.appid = exdata.data.appid;
                  app.globalData.qrindex = 0;
                  wx.hideToast();
                  console.log('qrcode', exdata);
                  console.log('minute----', minute);

                  that.createQrCode(exdata.data.mxqrcode + '#' + that.data.flashflag, "mycanvas", size.w, size.h);
                  that.setData({
                    flashflag: 0
                  });
                  minute = 1;
                } else {
                  that.offlineCreateQrcode();
                }
              },
              fail: function (res) {
                console.log('madecode失败，将无法正常使用开放接口等服务', res);
                setTimeout(that.screateQrcode, 200);
                //callback(res)
                wx.hideToast();
                that.offlineCreateQrcode();
              }
            })
          } else {
            that.offlineCreateQrcode();
          }
        }
      })

    }
  }
  ,
  offlineCreateQrcode() {
    if (app.globalData.qrindex < app.globalData.qrcodes.length) {
      var that = this;
      var size = that.setCanvasSize();//动态设置画布大小
      minute = 1;
      var inqrcode = app.globalData.qrcodes[app.globalData.qrindex];
      //console.log('uselocaldata', inqrcode);
      that.createQrCode('gowechat://' + app.globalData.openid + '#' + app.globalData.appid + '#' + inqrcode + '#' + that.data.flashflag, "mycanvas", size.w, size.h);
      that.setData({
        flashflag: 0
      });
      app.globalData.qrindex += 1;
    }

  },

  autochecksign: function (isSign, openid) {
    var that = this;
    wx.request({
      url: openIdUrl,
      data: {
        openid: openid,
        nickname: that.data.userInfo.nickName,
        latitude: that.data.latitude,
        longitude: that.data.longitude,
        city: '杭州市'
      },
      success: function (res) {
        console.log('checksign成功', res)
        var tisSign = res.data.isSign && res.data.bindMobile;
        if (tisSign) {
          /// 设置屏幕亮度
          wx.setScreenBrightness({
            value: 0.8
          })
        } else {
          wx.hideToast();
        }
        that.setData({
          openid: res.data.openid,
          issign: tisSign,
          extraData: res.data.exdata,
          bindMobile: res.data.bindMobile,
          array: res.data.valarray,
          keyarray: res.data.keyarray,
          showcard: res.data.showcard
        });
        app.globalData.bindMobile = res.data.bindMobile;
        if (res.data.isDebt) {
          wx.redirectTo({
            url: '../payList/payList'
          })
        }
        if (res.data.needCheck && res.data.RNameChecked == false && res.data.bindMobile) {
          wx.redirectTo({
            url: '../name/index'
          })
        } else {
          if (res.data.isSign && res.data.bindMobile) {

            var st = setTimeout(function () {
              that.screateQrcode();
              clearTimeout(st);
            }, 1000)

            clearInterval(ist);
            ist = setInterval(function () {
              if (minute >= 60) {
                minute = 1;
                that.screateQrcode();
              }
              minute += 1;
            }, 1000)

          }
          else if (!res.data.bindMobile && res.data.isSign) {
            that.setData({
              issign: false
            });
              wx.hideToast();
              that.getLocation();
          }
        }

      },
      fail: function (res) {
        //用户离线
        that.offlineCreateQrcode();
      }
    });

  },

  //适配不同屏幕大小的canvas
  setCanvasSize: function () {
    var size = {};
    try {
      var res = wx.getSystemInfoSync();
      var scale = 750 / 550;//不同屏幕下canvas的适配比例；设计稿是750宽
      var width = res.windowWidth / scale;
      var height = width;//canvas画布为正方形
      size.w = width;
      size.h = height;
    } catch (e) {
      // Do something when catch error
      console.log("获取设备信息失败" + e);
    }
    return size;
  },

  createQrCode: function (url, canvasId, cavW, cavH) {
    //调用插件中的draw方法，绘制二维码图片
    QR.qrApi.draw(url, canvasId, cavW, cavH);
  },

  //获取临时缓存照片路径，存入data中
  canvasToTempImage: function () {
    var that = this;
    wx.canvasToTempFilePath({
      canvasId: 'mycanvas',
      success: function (res) {
        var tempFilePath = res.tempFilePath;
        console.log("********" + tempFilePath);
        that.setData({
          imagePath: tempFilePath,
        });
      },
      fail: function (res) {
        console.log(res);
      }
    });
  },
  //点击图片进行预览，长按保存分享图片
  previewImg: function (e) {
    wx.canvasToTempFilePath({
      canvasId: 'mycanvas',
      success: function (res) {
        var tempFilePath = res.tempFilePath;
        wx.previewImage({
          current: tempFilePath, // 当前显示图片的http链接
          urls: [tempFilePath] // 需要预览的图片http链接列表
        })
      },
      fail: function (res) {
        console.log(res);
      }
    });

  },

  hdscreateQrcode: function () {
    var that = this;
    that.setData({
      flashflag: 1
    });
    that.screateQrcode();
    minute = 1;
  },

  formSubmit: function (e) {
    var that = this;
    var url = e.detail.value.url + '&' + Date.now();
    that.screateQrcode();
    that.setData({
      maskHidden: false,
    });
    wx.showToast({
      title: '生成中...',
      icon: 'loading',
      duration: 1000
    });
    var st = setTimeout(function () {
      wx.hideToast()
      var size = that.setCanvasSize();
      //绘制二维码
      //that.createQrCode(url,"mycanvas",size.w,size.h);
      that.setData({
        maskHidden: true
      });
      clearTimeout(st);
    }, 2000)

  },

  //立即开通
  btnRegisterTap: function () {
    var that = this;
    if (!that.data.isgetuser) {
      wx.showToast({
        title: '请授权小程序用户权限，谢谢！',
        icon: 'error',
        duration: 5000
      });
      return;
    }
    if (that.data.checkProtocol == 'B') {
      if (app.VersionCompare(app.globalData.version, '6.5.9')) {
        wx.showToast({
          title: '请将您的微信升级到6.5.9以上',
          icon: 'error',
          duration: 5000
        })
      }
      else {
        if (app.globalData.bindMobile) {
          // 从商户小程序跳转到微信签约小程序
          wx.navigateToMiniProgram({
            appId: 'wxbd687630cd02ce1d', path: 'pages/index/index',
            extraData: that.data.extraData
            , success(res) {

            }, fail(res) {
              // 未成功跳转到签约小程序
            }
          });

        } else {
          wx.redirectTo({
            url: '../phone/index'
          })
        }

      }
    } else {
      wx.showToast({
        title: '请勾选确认服务协议！',
        icon: 'succes',
        duration: 2000
      })
    }

  },

  //跳转到协议页面
  gotoprotocol: function () {
    wx.navigateTo({
      url: '../service/service'
    })
  }

})

/**********************************************************************************
**********************************Page()外部动画函数*********************************
**********************************************************************************/

//弹出动画
function popp() {
  //plus顺时针旋转
  var animationPlus = wx.createAnimation({
    duration: 500,
    timingFunction: 'ease-out'
  })
  var animationBus = wx.createAnimation({
    duration: 500,
    timingFunction: 'ease-out'
  })
  var animationLine = wx.createAnimation({
    duration: 500,
    timingFunction: 'ease-out'
  })
  var animationCard = wx.createAnimation({
    duration: 500,
    timingFunction: 'ease-out'
  })

  var animationShare = wx.createAnimation({
    duration: 500,
    timingFunction: 'ease-out'
  })

  ///翻转角度定位
  animationPlus.rotateZ(180).step();
  animationBus.translate(-60, 0).rotateZ(180).opacity(1).step();
  animationLine.translate(60, 0).rotateZ(180).opacity(1).step();
  animationCard.translate(-3, 60).rotateZ(180).opacity(1).step();
  animationShare.translate(-3, -60).rotateZ(180).opacity(1).step();

  this.setData({
    animationPlus: animationPlus.export(),
    animationBus: animationBus.export(),
    animationLine: animationLine.export(),
    animationCard: animationCard.export(),
    animationShare: animationShare.export(),
  })
}

//收回动画
function takeback() {
  //plus逆时针旋转
  var animationPlus = wx.createAnimation({
    duration: 500,
    timingFunction: 'ease-out'
  })
  var animationBus = wx.createAnimation({
    duration: 500,
    timingFunction: 'ease-out'
  })
  var animationLine = wx.createAnimation({
    duration: 500,
    timingFunction: 'ease-out'
  })
  var animationCard = wx.createAnimation({
    duration: 500,
    timingFunction: 'ease-out'
  })
  var animationShare = wx.createAnimation({
    duration: 500,
    timingFunction: 'ease-out'
  })
  animationPlus.rotateZ(0).step();
  animationBus.translate(0, 0).rotateZ(0).opacity(0).step();
  animationLine.translate(0, 0).rotateZ(0).opacity(0).step();
  animationCard.translate(0, 0).rotateZ(0).opacity(0).step();
  animationShare.translate(0, 0).rotateZ(0).opacity(0).step();
  this.setData({
    animationPlus: animationPlus.export(),
    animationBus: animationBus.export(),
    animationLine: animationLine.export(),
    animationCard: animationCard.export(),
    animationShare: animationShare.export(),
  })
}