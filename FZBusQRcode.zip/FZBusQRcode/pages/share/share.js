var util = require("../../utils/util.js");
var cfg = require('../../config');
const openIdUrl = cfg.openIdUrl;
const serverUrl = cfg.serverUrl;
var app = getApp();
Page({
  data:{
    registBtnTxt:"完成",
    registBtnBgBgColor:"#034d91",
    getSmsCodeBtnTxt:"获取验证码",
    getSmsCodeBtnColor:"#034d91",
    btnLoading:false,
    registDisabled:false,
    smsCodeDisabled:false,
    inputUserName: '',
    inputPassword: '',
    phoneNum: '',
    extraData:null
  },

  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    app.getUserOpenId(this.initfun);
  },
  onReady:function(){
    // 页面渲染完成
    
  },
  onShow: function (res) {
    // 页面显示
    this.autochecksign();
    console.log('serverUrl---' + serverUrl);
  },
  onHide:function(){
    // 页面隐藏
    
  },
  onUnload:function(){
    // 页面关闭
    
  },


  


})