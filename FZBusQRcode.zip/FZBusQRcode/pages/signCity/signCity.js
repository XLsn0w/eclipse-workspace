var app = getApp();

Page({

  data: {
    items: [],
    isNull: true
  },

  onLoad: function (options) {
    this.getOpenCitys(); 
  },

  onShow: function () {
  },

  onReady: function () {
    wx.setNavigationBarTitle({
      title: '已签约城市'
    })
  },

  selectCity: function () {

     console.log('lllllllll');

  },

  getOpenCitys: function () {
    var that = this;
    wx.request({
      url: 'https://wx.hzgolong.com/wechat/getOpenCitys',
      data: {
        openid: app.globalData.openid
      },
      success: function (res) {
        console.log('拉取getOpenlines', res)
        if (res.data.items.length > 0) {
          console.log('items count > 0');
          that.setData({
            items: res.data.items,
            isNull: false
          });
        } else {
          console.log('items count = 0');
          that.setData({
            isNull: true
          });
        }


      },
      fail: function (res) {

      }
    })
  }

})
