const serverUrl = require('../../config').serverUrl;
var app = getApp();
var city = null;
Page({

  data: {
    items: [],
    isNull: true
  },

  onLoad: function (options) {
    this.getRecord();  
    if (options != null && options.city != null) {
      city == options.city;
      console.log('options.city--->', options.city);
    }
  },

  onPullDownRefresh: function () {
    console.log('下拉刷新');
    // this.getRecord(); 
  },

  onReady: function () {
    city = wx.getStorageSync('city');
    wx.setNavigationBarTitle({
      title: city + '乘车记录'
    })
  },
  getRecord:function(){
    var that=this;
    var city = wx.getStorageSync('city');
    wx.request({
      url: serverUrl+'wechat/getRecord',
      data: {
        openid: app.globalData.openid,
        state:1,
        city: city
      },
      success: function (res){
        console.log('getRecord', res)
        if (res.data.items.length > 0) {
          console.log('items length > 0');
          that.setData({
            items: res.data.items,
            isNull: false
          });
        } else {
          console.log('items length = 0');
          that.setData({
            isNull: true
          });
        }
      },
      fail: function (res) {
        console.log('getRecord-fail', res)
      }
    })
  }
})
