var app = getApp();
const serverUrl = require('../../config').serverUrl;
Page({

  data: {
    items: [],
    isNull: true,
    registBtnTxt: "结清欠款",
    registBtnBgBgColor: "#fff",
    paydata:{}
  },

  onLoad: function (options) {
    this.getRecord();  
  },

  onPullDownRefresh: function () {
    console.log('下拉刷新');
    // this.getRecord(); 
  },

  onReady: function () {
    wx.setNavigationBarTitle({
      title: '结清欠款'
    })
  },
  pay: function () {
    var city = wx.getStorageSync('city');
    var that = this;
    console.log('debt-city',city);
    wx.request({
      url: serverUrl + 'wechat/getRecordDebt',
      data: {
        openid: app.globalData.openid,
        city: city
      },
      success: function (res) {
        console.log('getdebt', res)
        if (res.data.items.length > 0) {
          console.log('items length > 0');
          that.setData({
            items: res.data.items,
            paydata: res.data.paydata,
            isNull: false
          });
          wx.requestPayment({
            timeStamp: res.data.paydata.timeStamp,
            nonceStr: res.data.paydata.nonceStr,   //字符串随机数
            package: res.data.paydata.package,
            signType: res.data.paydata.signType,
            paySign: res.data.paydata.paySign,
            'success': function (res) {
              console.log(res.errMsg);    //requestPayment:ok==>调用支付成功
              wx.showToast({
                title: '付款成功',
                icon: 'success',
                duration: 1000
              });
              wx.redirectTo({
                url: '../qrcode/index'
              })
            },
            'fail': function (res) {
              console.log(res.errMsg);
            },
            'complete': function (res) {
              console.log(res.errMsg);
            }
          })
        } else {
          console.log('items length = 0');
          that.setData({
            isNull: true
          });
        }
      },
      fail: function (res) {

      }
    })
   
  },

  getRecord:function(){
    var city = wx.getStorageSync('city');
    var that=this;
    wx.request({
      url: serverUrl+'wechat/getRecordDebt',
      data: {
        openid: app.globalData.openid,
        city: city
      },
      success: function (res){
        console.log('getRecord', res)
        if (res.data.items.length > 0) {
          console.log('items length > 0');
          that.setData({
            items: res.data.items,
            paydata:res.data.paydata,
            isNull: false
          });
        } else {
          console.log('items length = 0');
          that.setData({
            isNull: true
          });
        }
      },
      fail: function (res) {
        
      }
    })
  }
})
