var app = getApp();
// var host = "https://www.busqrcode.com"
const host = require('../../config').serverUrl;

var city = null;

Page({

  data: {
    items: [],
    isNull: true
  },

  onLoad: function (options) {
    this.getOpenlines(); 

    if (options != null && typeof (options.city) != "undefined") {
      city == options.city;
      console.log('options.city--->', options.city);
    }
  },

  onShow: function (options) {
    console.log('line-onShow options', options);
    var pageslist = getCurrentPages();
    console.log('pageslist---' ,pageslist);
  },

  onReady: function () {
    city = wx.getStorageSync('city');
    wx.setNavigationBarTitle({
      title: city +'开通路线'
    })
  },

  getOpenlines: function () {
    var that = this;
    var city = wx.getStorageSync('city');
    wx.request({
      url: host + '/wechat/getOpenlines',
      data: {
        openid: app.globalData.openid,
        city: city
      },
      success: function (res) {
        console.log('拉取getOpenlines', res)
        if (res.data.items.length > 0) {
          console.log('items count > 0');
          that.setData({
            items: res.data.items,
            isNull: false
          });
        } else {
          console.log('items count = 0');
          that.setData({
            isNull: true
          });
        }


      },
      fail: function (res) {

      }
    })
  }

})
