/**
 * 小程序配置文件
 */
// var host = "www.busqrcode.com"
var host = "www.cmeeol.com"

var config = {

  // 下面的地址配合云端 Server 工作
  host,

  serverUrl: `https://${host}/`,

  // 用code换取openId
  openIdUrl: `https://${host}/wechat/IsSign?mode=3`,

};

module.exports = config
