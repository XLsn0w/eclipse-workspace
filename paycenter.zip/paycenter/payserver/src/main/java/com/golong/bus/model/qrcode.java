package com.golong.bus.model;

public class qrcode {
    private String data;
      
    private String qrContent;
      
    private String qrContent2;
      
    private String tradeType;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getQrContent() {
		return qrContent;
	}

	public void setQrContent(String qrContent) {
		this.qrContent = qrContent;
	}

	public String getQrContent2() {
		return qrContent2;
	}

	public void setQrContent2(String qrContent2) {
		this.qrContent2 = qrContent2;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}
}
