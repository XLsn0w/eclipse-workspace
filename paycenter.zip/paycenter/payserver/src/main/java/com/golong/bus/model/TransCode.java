package com.golong.bus.model;
/**
 * 二维码的数据结构
 * @author zhangchong
 *
 */
public class TransCode {
	//参数
	private String TDCCREATETIME;
	private String MAC;
	private String JSON;
	
	public String getTDCCREATETIME() {
		return TDCCREATETIME;
	}
	public void setTDCCREATETIME(String tDCCREATETIME) {
		TDCCREATETIME = tDCCREATETIME;
	}
	public String getMAC() {
		return MAC;
	}
	public void setMAC(String mAC) {
		MAC = mAC;
	}
	public String getJSON() {
		return JSON;
	}
	public void setJSON(String jSON) {
		JSON = jSON;
	}
	

	
	
	
	
	
//	private String signature;
//	private String algorithmid;
//	private String keyid;
//	private String guid;
//	private String tdctype;
//	private String paytype;
//	private String citycode;
//	private String uuid;
//	private String userid;
//	private String certificateCreateTime;
//	private String certificateFallureTime;
//	private String consumptionLimit;
//	private String useingScenes;
//	private String tdcFallureTime;
//	private String taccode;
//	
//	
//	
//	public String getSignature() {
//		return signature;
//	}
//	public void setSignature(String signature) {
//		this.signature = signature;
//	}
//	public String getAlgorithmid() {
//		return algorithmid;
//	}
//	public void setAlgorithmid(String algorithmid) {
//		this.algorithmid = algorithmid;
//	}
//	public String getKeyid() {
//		return keyid;
//	}
//	public void setKeyid(String keyid) {
//		this.keyid = keyid;
//	}
//	public String getGuid() {
//		return guid;
//	}
//	public void setGuid(String guid) {
//		this.guid = guid;
//	}
//	public String getTdctype() {
//		return tdctype;
//	}
//	public void setTdctype(String tdctype) {
//		this.tdctype = tdctype;
//	}
//	public String getPaytype() {
//		return paytype;
//	}
//	public void setPaytype(String paytype) {
//		this.paytype = paytype;
//	}
//	public String getCitycode() {
//		return citycode;
//	}
//	public void setCitycode(String citycode) {
//		this.citycode = citycode;
//	}
//	public String getUuid() {
//		return uuid;
//	}
//	public void setUuid(String uuid) {
//		this.uuid = uuid;
//	}
//	public String getUserid() {
//		return userid;
//	}
//	public void setUserid(String userid) {
//		this.userid = userid;
//	}
//	public String getCertificateCreateTime() {
//		return certificateCreateTime;
//	}
//	public void setCertificateCreateTime(String certificateCreateTime) {
//		this.certificateCreateTime = certificateCreateTime;
//	}
//	public String getCertificateFallureTime() {
//		return certificateFallureTime;
//	}
//	public void setCertificateFallureTime(String certificateFallureTime) {
//		this.certificateFallureTime = certificateFallureTime;
//	}
//	public String getConsumptionLimit() {
//		return consumptionLimit;
//	}
//	public void setConsumptionLimit(String consumptionLimit) {
//		this.consumptionLimit = consumptionLimit;
//	}
//	public String getUseingScenes() {
//		return useingScenes;
//	}
//	public void setUseingScenes(String useingScenes) {
//		this.useingScenes = useingScenes;
//	}
//	public String getTdcFallureTime() {
//		return tdcFallureTime;
//	}
//	public void setTdcFallureTime(String tdcFallureTime) {
//		this.tdcFallureTime = tdcFallureTime;
//	}
//	public String getTaccode() {
//		return taccode;
//	}
//	public void setTaccode(String taccode) {
//		this.taccode = taccode;
//	}
//	public String getTdcCreateTime() {
//		return tdcCreateTime;
//	}
//	public void setTdcCreateTime(String tdcCreateTime) {
//		this.tdcCreateTime = tdcCreateTime;
//	}
//	public String getMac() {
//		return mac;
//	}
//	public void setMac(String mac) {
//		this.mac = mac;
//	}
	
	

}
